#!/bin/bash

export PYTHONPATH=$PYTHONPATH:/share/jproject/fg508/naha/StackGAN/
export CUDA_VISIBLE_DEVICES=0,1,2